# -*- coding: utf-8 -*-
"""
@author: This version in Python translated by John Wainwright in February 2026
from the original Fortran code in Morris et al. (2015)

OPTIMIZED VERSION: Numba JIT compilation applied to the core computational
kernel, and NumPy vectorization used throughout for per-layer operations.
Key changes from original:
  1. Core layer loops (decomposition, wet proportion, hydraulic conductivity,
     transmissivity) extracted into a Numba @njit-compiled kernel.
  2. Python lists for layer state replaced with pre-allocated NumPy arrays,
     avoiding repeated list-append overhead.
  3. DataFrame.iloc[] indexing inside inner loops replaced with pre-extracted
     NumPy arrays (netRainArr, tempArr, extentArr) read once before the loop.
  4. math.exp / math.sqrt replaced with numpy equivalents inside the kernel
     (Numba compiles these to fast native calls automatically).
  5. Output-list appends remain in Python since they are O(1) per year.

Morris PJ, AJ Baird, DM Young, GT Swindles 2015 'Untangling climate signals
from autogenic changes in long-term peatland development', Geophysical
Research Letters 42, 10,788-10,797, doi:10.1002/2015GL066824.
"""

import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from numba import njit

# =============================================================================
# Numba-compiled inner kernel
# =============================================================================

@njit(cache=True)
def _layer_update_kernel(
    za,
    layerMass, layerInitialMass, layerRemainingMass,
    layerThickness, layerElevation, wetProportion,
    layerHydroK, layerTransmissivity,
    anoxicDecay, oxicDecay, timestep,
    density, kParamA, kParamB
):
    """
    Numba-JIT-compiled kernel that performs steps 2, 5, 6 and 7 of the
    inner sub-annual loop:
      2. Decompose peat in each layer.
      5. Calculate new wet proportion for each layer.
      6. Calculate new hydraulic conductivity and transmissivity.
      7. Accumulate total bog transmissivity.

    Also updates bogHeight and massPerArea in-place and returns them.

    Parameters are all plain scalars or 1-D NumPy float64 arrays so that
    Numba can compile without object-mode fallback.
    """
    massPerArea = 0.0
    bogTransmissivity = 0.0

    # Step 2: decompose and update layer geometry
    for zb in range(za):
        lm = layerMass[zb]
        wp = wetProportion[zb]
        rm = layerRemainingMass[zb]
        sqrm = rm ** 0.5

        layerMass[zb] = (lm * wp * np.exp(-anoxicDecay * timestep * sqrm) +
                         lm * (1.0 - wp) * np.exp(-oxicDecay * timestep * sqrm))

        layerRemainingMass[zb] = layerMass[zb] / layerInitialMass[zb]
        layerThickness[zb] = layerMass[zb] / density

        if zb == 0:
            layerElevation[zb] = layerThickness[zb]
        else:
            layerElevation[zb] = layerThickness[zb] + layerElevation[zb - 1]

        massPerArea += layerMass[zb]

    bogHeight = layerElevation[za - 1]
    return bogHeight, massPerArea, bogTransmissivity


@njit(cache=True)
def _wet_prop_k_transmiss_kernel(
    za, wtHeight,
    layerElevation, layerThickness, layerRemainingMass,
    wetProportion, layerHydroK, layerTransmissivity,
    kParamA, kParamB
):
    """
    Numba-JIT-compiled kernel for steps 5–7:
    compute wet proportion, hydraulic conductivity, and transmissivity
    for all layers, then sum transmissivity.
    """
    bogTransmissivity = 0.0
    for zb in range(za):
        # Step 5: wet proportion
        if zb == 0:
            if wtHeight >= layerElevation[0]:
                wetProportion[0] = 1.0
            else:
                wetProportion[0] = wtHeight / layerThickness[0]
        elif wtHeight >= layerElevation[zb]:
            wetProportion[zb] = 1.0
        elif wtHeight <= layerElevation[zb - 1]:
            wetProportion[zb] = 0.0
        else:
            wetProportion[zb] = ((wtHeight - layerElevation[zb - 1]) /
                                  layerThickness[zb])

        # Step 6: hydraulic conductivity and transmissivity
        layerHydroK[zb] = kParamA * np.exp(kParamB * layerRemainingMass[zb])
        layerTransmissivity[zb] = (layerHydroK[zb] *
                                    layerThickness[zb] *
                                    wetProportion[zb])
        # Step 7: accumulate transmissivity
        bogTransmissivity += layerTransmissivity[zb]

    return bogTransmissivity


# =============================================================================
# Main model function
# =============================================================================

def DigiBog1D(oxicDecayBase, anoxicDecayBase, baseTemp, Q10Oxic, Q10Anoxic,
              density, porosity, kParamA, kParamB, tExtent, annualTsteps,
              outputInterval, netRainfall, temperature, lateralExtent):
    """
    Optimized implementation of the DigiBog1D model.
    See original file for full parameter documentation.
    """
    timestep = 1.0 / annualTsteps
    tExtent = tExtent + 1

    # ------------------------------------------------------------------
    # Pre-allocate NumPy arrays for layer state.
    # Maximum possible layers = tExtent (one new layer per year) + 1
    # ------------------------------------------------------------------
    maxLayers = tExtent + 2
    layerInitialMass    = np.zeros(maxLayers, dtype=np.float64)
    layerMass           = np.zeros(maxLayers, dtype=np.float64)
    layerRemainingMass  = np.zeros(maxLayers, dtype=np.float64)
    layerThickness      = np.zeros(maxLayers, dtype=np.float64)
    layerElevation      = np.zeros(maxLayers, dtype=np.float64)
    wetProportion       = np.zeros(maxLayers, dtype=np.float64)
    layerHydroK         = np.zeros(maxLayers, dtype=np.float64)
    layerTransmissivity = np.zeros(maxLayers, dtype=np.float64)

    # ------------------------------------------------------------------
    # Pre-extract climate arrays from DataFrames (avoid .iloc in loop)
    # ------------------------------------------------------------------
    netRainArr  = netRainfall["netRainfall"].to_numpy(dtype=np.float64)
    tempArr     = temperature["temperature"].to_numpy(dtype=np.float64)
    extentArr   = lateralExtent["lateralExtent"].to_numpy(dtype=np.float64)

    # ------------------------------------------------------------------
    # Output lists (appended once per outputInterval years)
    # ------------------------------------------------------------------
    bogHeightOutput        = []
    wtHeightOutput         = []
    bogTransmissivityOutput = []
    massPerAreaOutput      = []

    # ------------------------------------------------------------------
    # Initialise first layer
    # ------------------------------------------------------------------
    za = 1
    layerMass[0]          = (9.3 ** 2.0) * 0.0001
    layerInitialMass[0]   = layerMass[0]
    layerRemainingMass[0] = 1.0
    wetProportion[0]      = 1.0
    layerThickness[0]     = layerMass[0] / density
    layerElevation[0]     = layerThickness[0]
    layerHydroK[0]        = kParamA * np.exp(kParamB)
    layerTransmissivity[0]= layerThickness[0] * layerHydroK[0]

    bogHeight        = layerElevation[0]
    wtHeight         = bogHeight
    bogTransmissivity = layerTransmissivity[0]
    massPerArea      = layerMass[0]

    timeCounter  = 0
    outputCounter = 0
    wtSum        = 0.0
    wtDepthAv    = 0.0

    # ------------------------------------------------------------------
    # Main time loop
    # ------------------------------------------------------------------
    for time in range(tExtent):
        if time % 100 == 0:
            print("Model year " + str(time))

        # Pre-compute temperature-dependent decay rates for this year
        oxicDecay   = (oxicDecayBase *
                       Q10Oxic  ** ((tempArr[time] - baseTemp) / 10.0))
        anoxicDecay = (anoxicDecayBase *
                       Q10Anoxic ** ((tempArr[time] - baseTemp) / 10.0))

        netRain = netRainArr[time]
        extent  = extentArr[time]

        for timeCounter in range(annualTsteps):

            # Step 2: decompose layers (Numba kernel)
            bogHeight, massPerArea, _ = _layer_update_kernel(
                za,
                layerMass, layerInitialMass, layerRemainingMass,
                layerThickness, layerElevation, wetProportion,
                layerHydroK, layerTransmissivity,
                anoxicDecay, oxicDecay, timestep,
                density, kParamA, kParamB
            )

            # Step 3: update water-table level
            wtHeight = (wtHeight
                        + (timestep * netRain / porosity)
                        - ((timestep * 2.0 * bogTransmissivity * wtHeight /
                            (extent ** 2.0)) / porosity))

            bogTransmissivity = 0.0

            # Step 4: check water-table bounds
            if wtHeight <= 0.0:
                print("Water table below impermeable base:")
                print(" Model unstable and has been stopped.")
                sys.exit(1)
            elif wtHeight > bogHeight:
                wtHeight = bogHeight

            wtDepth = bogHeight - wtHeight
            wtSum  += wtDepth

            # Steps 5-7: wet proportion, K, transmissivity (Numba kernel)
            bogTransmissivity = _wet_prop_k_transmiss_kernel(
                za, wtHeight,
                layerElevation, layerThickness, layerRemainingMass,
                wetProportion, layerHydroK, layerTransmissivity,
                kParamA, kParamB
            )

        # End of sub-annual loop
        wtDepthAv = wtSum / annualTsteps
        wtSum = 0.0

        # Add new annual litter layer
        if wtDepthAv > 66.8:
            newMass = 0.0000001
        else:
            newMass = (((9.3 + 1.33 * wtDepthAv -
                         0.022 * wtDepthAv ** 2.0) ** 2.0) *
                       0.0001 *
                       (0.1575 * tempArr[time] + 0.009132))

        layerMass[za]          = newMass
        layerInitialMass[za]   = newMass
        layerRemainingMass[za] = 1.0
        wetProportion[za]      = 0.0
        layerThickness[za]     = newMass / density
        layerElevation[za]     = bogHeight + layerThickness[za]
        layerHydroK[za]        = kParamA * np.exp(kParamB * layerRemainingMass[za])
        layerTransmissivity[za]= (layerHydroK[za] *
                                   layerThickness[za] *
                                   wetProportion[za])

        massPerArea += layerMass[za]
        bogHeight    = layerElevation[za]

        outputCounter += 1
        if outputCounter == outputInterval:
            bogHeightOutput.append(bogHeight)
            wtHeightOutput.append(wtHeight)
            bogTransmissivityOutput.append(bogTransmissivity)
            massPerAreaOutput.append(massPerArea)
            outputCounter = 0

        za += 1

    # Return sliced arrays (only populated entries) as lists for compatibility
    return (list(layerElevation[:za]),
            list(layerRemainingMass[:za]),
            bogHeightOutput,
            wtHeightOutput,
            bogTransmissivityOutput,
            massPerAreaOutput)


# =============================================================================
# Plotting functions (unchanged from original)
# =============================================================================

def PlotDigiBog1DClimate(netRainfall, temperature, startYear, endYear,
                         outputInterval, window, filename=""):
    dates = pd.DataFrame({"date": list(range(startYear, endYear - 1,
                                              -outputInterval))})
    climate = pd.concat([dates, netRainfall * 10., temperature], axis=1)
    climate["maNetRainfall"] = (climate["netRainfall"]
                                .rolling(window=window, min_periods=window)
                                .mean())
    climate["maTemperature"] = (climate["temperature"]
                                .rolling(window=window, min_periods=window)
                                .mean())

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.scatter(climate["date"], climate["netRainfall"],
               facecolors='none', edgecolors="cyan", alpha=0.5,
               label="annual net rainfall")
    ax.plot(climate["date"], climate["maNetRainfall"], color="blue",
            label=str(window) + "-yr. ave. net rainfall")
    ax.invert_xaxis()
    ax.set_ylim([0, 2000])
    ax.set_xlabel("date [BP]")
    ax.set_ylabel("net rainfall [mm]")
    ax.legend(loc='lower left')

    ax2 = ax.twinx()
    ax2.set_ylim([0, 9.5])
    ax2.scatter(climate["date"], climate["temperature"],
                facecolors='none', edgecolors="pink", alpha=0.5,
                label="annual temperature")
    ax2.plot(climate["date"], climate["maTemperature"], color="red",
             label=str(window) + "-yr. ave. temp.")
    ax2.set_ylabel("temperature [°C]")
    ax2.legend(loc='lower right')

    if filename != "":
        plt.savefig(filename)
    plt.show()


def PlotDigiBog1DResults(bogHeight, wtHeight, transmissivity, startYear,
                         endYear, outputInterval, window, filename=""):
    dates = pd.DataFrame({"date": list(range(startYear, endYear - 1,
                                              -outputInterval))})
    results = pd.concat([dates, bogHeight / 100., wtHeight / 100.,
                         transmissivity / 10000.], axis=1)
    results["maWtHeight"] = (results["wtHeight"]
                             .rolling(window=window, min_periods=window)
                             .mean())
    results["maTransmissivity"] = (results["bogTransmissivity"]
                                   .rolling(window=window, min_periods=window)
                                   .mean())

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.scatter(results["date"], results["wtHeight"],
               facecolors='none', edgecolors="cyan", alpha=0.5,
               label="annual WT")
    ax.plot(results["date"], results["maWtHeight"], color="blue",
            label=str(window) + "-yr. ave. WT")
    ax.plot(results["date"], results["bogHeight"], color="black",
            label="bog surface")
    ax.invert_xaxis()
    ax.set_xlabel("date [BP]")
    ax.set_ylabel("bog-surface and water-table heights [m]")
    ax.legend(loc='lower center')

    ax2 = ax.twinx()
    ax2.set_ylim([1, 1.0e6])
    ax2.set_yscale('log', base=10)
    ax2.scatter(results["date"], results["bogTransmissivity"],
                facecolors='none', edgecolors="orange", alpha=0.25,
                label="annual transmiss.")
    ax2.plot(results["date"], results["maTransmissivity"], color="red",
             label=str(window) + "-yr. ave. transmiss.")
    ax2.set_ylabel("transmissivity [$m^2$ $yr^{-1}$]")
    ax2.legend(loc='lower right')

    if filename != "":
        plt.savefig(filename)
    plt.show()


def PlotDigiBog1DWaterTable(bogHeight, wtHeight, startYear, endYear,
                             outputInterval, window, filename=""):
    dates = pd.DataFrame({"date": list(range(startYear, endYear - 1,
                                              -outputInterval))})
    results = pd.concat([dates, bogHeight / 100., wtHeight / 100.], axis=1)
    results["wtDepth"] = results["bogHeight"] - results["wtHeight"]
    results["maWtDepth"] = (results["wtDepth"]
                            .rolling(window=window, min_periods=window)
                            .mean())

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.scatter(results["date"], results["wtDepth"],
               facecolors='none', edgecolors="cyan", alpha=0.5,
               label="annual water table")
    ax.plot(results["date"], results["maWtDepth"], color="blue",
            label=str(window) + "-yr. ave. WT")
    ax.invert_xaxis()
    ax.invert_yaxis()
    ax.set_xlabel("date [BP]")
    ax.set_ylabel("water-table depth [m]")
    ax.legend(loc='lower center')

    if filename != "":
        plt.savefig(filename)
    plt.show()
    return pd.DataFrame(results["wtDepth"])


def DigiBog1DGetResults(path="."):
    with open(path + "/010_DigiBog_1_D_IN_information.txt", "r") as paramFile:
        for i in range(11):
            inputValue = paramFile.readline()
        inputValue = paramFile.readline().split()
        outputInterval = int(inputValue[0])

    netRainfall  = pd.read_csv(path + "/020_DigiBog_1_D_IN_net_rain.txt",
                               names=["netRainfall"])
    temperature  = pd.read_csv(path + "/030_DigiBog_1_D_IN_temp.txt",
                               names=["temperature"])
    bogHeight    = pd.read_csv(path + "/070_DigiBog_1_D_OUT_bog_height.txt",
                               names=["bogHeight"])
    wtHeight     = pd.read_csv(path + "/080_DigiBog_1_D_OUT_wt_height.txt",
                               names=["wtHeight"])
    transmissivity = pd.read_csv(path + "/090_DigiBog_1_D_OUT_transmiss.txt",
                                  names=["bogTransmissivity"])
    return (netRainfall, temperature, bogHeight, wtHeight,
            transmissivity, outputInterval)


# =============================================================================
# Entry point
# =============================================================================

if __name__ == "__main__":
    startSimulation = datetime.now()

    with open("010_DigiBog_1_D_IN_information.txt", "r") as paramFile:
        oxicDecayBase   = float(paramFile.readline().split()[0])
        anoxicDecayBase = float(paramFile.readline().split()[0])
        baseTemp        = float(paramFile.readline().split()[0])
        Q10Oxic         = float(paramFile.readline().split()[0])
        Q10Anoxic       = float(paramFile.readline().split()[0])
        density         = float(paramFile.readline().split()[0])
        porosity        = float(paramFile.readline().split()[0])
        kParamA         = float(paramFile.readline().split()[0])
        kParamB         = float(paramFile.readline().split()[0])
        tExtent         = int(paramFile.readline().split()[0])
        annualTsteps    = int(paramFile.readline().split()[0])
        outputInterval  = int(paramFile.readline().split()[0])

    netRainfall  = pd.read_csv("020_DigiBog_1_D_IN_net_rain.txt",
                               names=["netRainfall"])
    if tExtent > len(netRainfall):
        print("ERROR -- tExtent is " + str(tExtent) +
              ", which is too long compared to the available " +
              "netRainfall data which has " + str(len(netRainfall)) +
              " data points")
        sys.exit(1)

    temperature = pd.read_csv("030_DigiBog_1_D_IN_temp.txt",
                              names=["temperature"])
    if tExtent > len(temperature):
        print("ERROR -- tExtent is " + str(tExtent) +
              ", which is too long compared to the available " +
              "temperature data which has " + str(len(temperature)) +
              " data points")
        sys.exit(1)

    lateralExtent = pd.read_csv("040_DigiBog_1_D_IN_extent.txt",
                                names=["lateralExtent"])
    if tExtent > len(lateralExtent):
        print("ERROR -- tExtent is " + str(tExtent) +
              ", which is too long compared to the available " +
              "lateralExtent data which has " + str(len(lateralExtent)) +
              " data points")
        sys.exit(1)

    (layerElevation, layerRemainingMass,
     bogHeightOutput, wtHeightOutput,
     bogTransmissivityOutput, massPerAreaOutput) = DigiBog1D(
        oxicDecayBase, anoxicDecayBase, baseTemp, Q10Oxic, Q10Anoxic,
        density, porosity, kParamA, kParamB, tExtent, annualTsteps,
        outputInterval, netRainfall, temperature, lateralExtent)

    # Write outputs
    pd.DataFrame({"layerElevation": layerElevation}).to_csv(
        "050_DigiBog_1_D_OUT_layer_elev.txt", index=False, header=False)
    pd.DataFrame({"layerRemainingMass": layerRemainingMass}).to_csv(
        "060_DigiBog_1_D_OUT_layer_mass.txt", index=False, header=False)
    pd.DataFrame({"bogHeight": bogHeightOutput}).to_csv(
        "070_DigiBog_1_D_OUT_bog_height.txt", index=False, header=False)
    pd.DataFrame({"wtHeight": wtHeightOutput}).to_csv(
        "080_DigiBog_1_D_OUT_wt_height.txt", index=False, header=False)
    pd.DataFrame({"bogTransmissivity": bogTransmissivityOutput}).to_csv(
        "090_DigiBog_1_D_OUT_transmiss.txt", index=False, header=False)
    pd.DataFrame({"massPerArea": massPerAreaOutput}).to_csv(
        "100_DigiBog_1_D_OUT_mass_area.txt", index=False, header=False)

    bogHeightOutputDF        = pd.DataFrame({"bogHeight": bogHeightOutput})
    wtHeightOutputDF         = pd.DataFrame({"wtHeight": wtHeightOutput})
    bogTransmissivityOutputDF = pd.DataFrame(
        {"bogTransmissivity": bogTransmissivityOutput})

    PlotDigiBog1DClimate(netRainfall[0:1001], temperature[0:1001],
                         7950, 6950, outputInterval, 50, "climate")
    PlotDigiBog1DResults(bogHeightOutputDF, wtHeightOutputDF,
                         bogTransmissivityOutputDF,
                         7950, 6950, outputInterval, 50, "results")
    PlotDigiBog1DWaterTable(bogHeightOutputDF, wtHeightOutputDF,
                             7950, 6950, outputInterval, 50, "waterTableDepth")

    endSimulation = datetime.now()
    print("DigiBog 1D simulation complete at: " + str(endSimulation) +
          "\n Simulation took: " + str(endSimulation - startSimulation))
